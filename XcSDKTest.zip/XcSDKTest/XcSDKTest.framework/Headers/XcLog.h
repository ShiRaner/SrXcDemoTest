//
//  XcLog.h
//  XcSDKTest
//
//  Created by shiran on 2020/9/14.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface XcLog : NSObject

- (NSString *)xcLog;

@end

NS_ASSUME_NONNULL_END
