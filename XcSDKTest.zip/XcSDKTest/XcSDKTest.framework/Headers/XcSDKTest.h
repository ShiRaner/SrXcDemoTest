//
//  XcSDKTest.h
//  XcSDKTest
//
//  Created by shiran on 2020/9/14.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double XcSDKTestVersionNumber;
 
FOUNDATION_EXPORT const unsigned char XcSDKTestVersionString[];

/** SDK版本号 */
#define MiniAppMarket_IOS_SDK_VERSION @"1.0.0"

#import <XcSDKTest/XcLog.h>

